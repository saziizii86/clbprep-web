// src/pages/Listening/5. Discussion/ListeningDiscussionTest.tsx
import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, ArrowRight, Clock, Volume2, 
  Play, Pause, CheckCircle, Info, Headphones,
  AlertCircle, RotateCcw, X, Video
} from 'lucide-react';

// Types
interface QuestionOption {
  id: string;
  text?: string;
}

interface Question {
  id: string;
  questionText: string;
  type: string;
  options: QuestionOption[];
  correctAnswer: string;
  audioUrl?: string | null;
  transcript?: string | null;
}

interface Section {
  id: string;
  title: string;
  audioUrl?: string;
  audioDuration: number;
  transcript?: string;
  questions: Question[];
}

interface Scenario {
  id: string;
  title: string;
  skill: string;
  taskName: string;
  taskType: string;
  totalTime: number;
  instructions?: string;
  contextImage?: string;
  contextDescription?: string;
  videoUrl?: string;
  sections: Section[];
  uploadedFiles?: any;
}

interface TestResults {
  scenarioId: string;
  answers: Record<string, string>;
  score: number;
  totalQuestions: number;
  timeSpent: number;
}

interface ListeningDiscussionTestProps {
  scenario: Scenario;
  onBack: () => void;
  onComplete: (results: TestResults) => void;
}

type TestPhase = 'instructions' | 'media' | 'question' | 'results' | 'answerKey';

const ListeningDiscussionTest: React.FC<ListeningDiscussionTestProps> = ({ 
  scenario, 
  onBack, 
  onComplete 
}) => {
  // State
  const [phase, setPhase] = useState<TestPhase>('instructions');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showTranscript, setShowTranscript] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [mediaProgress, setMediaProgress] = useState(0);
  const [mediaCurrentTime, setMediaCurrentTime] = useState(0);
  const [mediaDuration, setMediaDuration] = useState(0);
  const [hasPlayedMedia, setHasPlayedMedia] = useState(false);
  const [timeLeft, setTimeLeft] = useState(90);
  const [testStartTime, setTestStartTime] = useState<number | null>(null);
  const [testResults, setTestResults] = useState<TestResults | null>(null);

  // Refs
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Get video URL (check multiple possible locations)
  const videoUrl = scenario.videoUrl || 
    scenario.uploadedFiles?.videoFile?.storageUrl || 
    scenario.uploadedFiles?.videoFile?.data;

  // Get audio URL as fallback
  const audioUrl = scenario.sections?.[0]?.audioUrl || 
    scenario.uploadedFiles?.sectionAudios?.[0]?.storageUrl ||
    scenario.uploadedFiles?.sectionAudios?.[0]?.data;

  // Get transcript
  const transcript = scenario.sections?.[0]?.transcript || '';

  // Get all questions from all sections
  const allQuestions = scenario.sections?.flatMap(s => s.questions) || [];
  const totalQuestions = allQuestions.length || 8;
  const currentQuestion = allQuestions[currentQuestionIndex];

  // Determine media type
  const hasVideo = !!videoUrl;
  const hasAudio = !!audioUrl;

  // Instructions from scenario
  const instructionsText = scenario.instructions || 
    scenario.contextDescription || 
    'You will watch a discussion between three coworkers. Listen carefully and answer the questions that follow.';

  // Timer for questions
  useEffect(() => {
    if (phase === 'question' && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            handleComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [phase, timeLeft]);

  // Start test timer when entering questions
  useEffect(() => {
    if (phase === 'question' && !testStartTime) {
      setTestStartTime(Date.now());
    }
  }, [phase]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const togglePlayPause = () => {
    const media = hasVideo ? videoRef.current : audioRef.current;
    if (media && !hasPlayedMedia) {
      if (isPlaying) {
        media.pause();
      } else {
        media.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    const media = hasVideo ? videoRef.current : audioRef.current;
    if (media) {
      const duration = media.duration;
      if (duration && isFinite(duration)) {
        const progress = (media.currentTime / duration) * 100;
        setMediaProgress(progress);
        setMediaCurrentTime(media.currentTime);
      }
    }
  };

  const handleLoadedMetadata = () => {
    const media = hasVideo ? videoRef.current : audioRef.current;
    if (media?.duration) {
      setMediaDuration(Math.floor(media.duration));
    }
  };

  const handleMediaEnded = () => {
    setIsPlaying(false);
    setHasPlayedMedia(true);
    setTimeout(() => setPhase('question'), 500);
  };

  const handleAnswerSelect = (questionId: string, answerId: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: answerId }));
  };

  const handleNext = () => {
    if (phase === 'instructions') {
      setPhase('media');
    } else if (phase === 'media') {
      if (hasVideo && videoRef.current) {
        videoRef.current.pause();
      }
      if (hasAudio && audioRef.current) {
        audioRef.current.pause();
      }
      setIsPlaying(false);
      setHasPlayedMedia(true);
      setPhase('question');
    } else if (phase === 'question') {
      if (currentQuestionIndex < allQuestions.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
      } else {
        handleComplete();
      }
    }
  };

  const handleBack = () => {
    if (phase === 'media') {
      setPhase('instructions');
    } else if (phase === 'question') {
      if (currentQuestionIndex > 0) {
        setCurrentQuestionIndex(prev => prev - 1);
      } else {
        setPhase('media');
        setHasPlayedMedia(false);
      }
    } else if (phase === 'results' || phase === 'answerKey') {
      setPhase('results');
    }
  };

  const handleComplete = () => {
    let correctCount = 0;
    allQuestions.forEach((q) => {
      if (answers[q.id] === q.correctAnswer) {
        correctCount++;
      }
    });

    const results: TestResults = {
      scenarioId: scenario.id,
      answers,
      score: correctCount,
      totalQuestions,
      timeSpent: Math.floor((Date.now() - (testStartTime ?? Date.now())) / 1000),
    };

    setTestResults(results);
    setPhase('results');
  };

  const resetTest = () => {
    setPhase('instructions');
    setCurrentQuestionIndex(0);
    setAnswers({});
    setHasPlayedMedia(false);
    setMediaProgress(0);
    setMediaCurrentTime(0);
    setTimeLeft(90);
    setShowTranscript(false);
    setTestStartTime(null);
    setIsPlaying(false);
  };

  const progressPercentage = phase === 'question' 
    ? ((currentQuestionIndex + 1) / totalQuestions) * 100 
    : 0;

  // ============== RENDER FUNCTIONS ==============

  const renderInstructions = () => (
    <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-slate-200 max-w-3xl mx-auto">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl mb-6 shadow-xl shadow-blue-500/25">
          {hasVideo ? <Video className="w-10 h-10 text-white" /> : <Headphones className="w-10 h-10 text-white" />}
        </div>
        <h2 className="text-3xl font-bold text-slate-900 mb-2 tracking-tight">Discussion</h2>
        <p className="text-slate-500 text-lg">{scenario.title?.replace(/_/g, ' ') || 'Listening Practice'}</p>
      </div>

      <div className="bg-gradient-to-br from-slate-50 to-blue-50/50 rounded-2xl p-6 mb-8 border border-slate-200/80">
        <h3 className="font-semibold text-slate-900 mb-5 flex items-center gap-2 text-lg">
          <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
            <Info className="w-4 h-4 text-blue-600" />
          </div>
          Instructions
        </h3>
        <div className="space-y-3">
          {[
            hasVideo 
              ? 'You will watch a discussion between speakers. You will see it only once.'
              : 'You will hear a discussion between speakers. You will hear it only once.',
            'After the discussion, you will answer 8 questions.',
            'Choose the best answer to each question.'
          ].map((text, i) => (
            <div key={i} className="flex items-start gap-4 group">
              <span className="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 text-white rounded-xl flex items-center justify-center text-sm font-bold shadow-lg shadow-blue-500/20 group-hover:scale-110 transition-transform">
                {i + 1}
              </span>
              <p className="text-slate-700 leading-relaxed pt-1">{text}</p>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={handleNext}
        className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl font-semibold text-lg hover:shadow-xl hover:shadow-blue-500/25 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-3"
      >
        Continue
        <ArrowRight className="w-5 h-5" />
      </button>
    </div>
  );

  const renderMedia = () => (
    <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-slate-200 max-w-3xl mx-auto">
      <div className="text-center">
        <div className="bg-gradient-to-br from-slate-50 to-blue-50/50 rounded-2xl p-6 mb-5 border border-slate-200/80">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
              <Info className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-xl text-slate-700">
              {hasVideo ? 'Watch' : 'Listen to'} the conversation. You will {hasVideo ? 'see' : 'hear'} it only <span className="text-orange-500 font-bold">once</span>.
            </p>
          </div>

          {/* Video Player */}
          {hasVideo ? (
            <div className="bg-black rounded-2xl overflow-hidden shadow-xl mb-4">
              <video
                ref={videoRef}
                src={videoUrl}
                className="w-full aspect-video"
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onEnded={handleMediaEnded}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
              />
              
              {/* Video Controls */}
              <div className="bg-slate-900 p-4">
                <div className="flex items-center gap-4">
                  <button
                    onClick={togglePlayPause}
                    disabled={hasPlayedMedia}
                    className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
                      hasPlayedMedia 
                        ? 'bg-slate-700 text-slate-500 cursor-not-allowed' 
                        : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:scale-105'
                    }`}
                  >
                    {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                  </button>

                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-slate-400 font-mono w-12">
                        {formatTime(Math.floor(mediaCurrentTime))}
                      </span>
                      <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 transition-all rounded-full"
                          style={{ width: `${mediaProgress}%` }}
                        />
                      </div>
                      <span className="text-sm text-slate-400 font-mono w-12">
                        {formatTime(mediaDuration)}
                      </span>
                    </div>
                  </div>

                  <button className="p-2 text-slate-400 hover:text-white transition">
                    <Volume2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ) : hasAudio ? (
            /* Audio Player - Same style as ListeningPracticeTest */
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <span className="font-semibold text-slate-900 text-lg">Audio</span>
                <span className="text-sm text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
                  {totalQuestions} questions follow
                </span>
              </div>

              <div className="flex items-center gap-4 mb-6">
                <button
                  onClick={togglePlayPause}
                  disabled={hasPlayedMedia}
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-lg ${
                    hasPlayedMedia 
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
                      : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:shadow-xl hover:shadow-blue-500/25 hover:scale-105'
                  }`}
                >
                  {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
                </button>

                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-slate-500 font-mono w-12">
                      {formatTime(Math.floor(mediaCurrentTime))}
                    </span>
                    <div className="flex-1 h-3 bg-slate-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 transition-all rounded-full"
                        style={{ width: `${mediaProgress}%` }}
                      />
                    </div>
                    <span className="text-sm text-slate-500 font-mono w-12">
                      {formatTime(mediaDuration)}
                    </span>
                  </div>
                </div>

                <button className="p-3 hover:bg-slate-100 rounded-xl transition">
                  <Volume2 className="w-5 h-5 text-slate-500" />
                </button>
              </div>

              {/* Tip */}
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl p-4 border border-amber-200/50">
                <p className="text-sm text-amber-800">
                  <span className="font-bold">Tip:</span> focus on keywords (numbers, dates, reasons, next steps).
                </p>
              </div>

              {/* Hidden Audio Element */}
              <audio
                ref={audioRef}
                src={audioUrl}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onEnded={handleMediaEnded}
              />
            </div>
          ) : (
            /* No Media Available */
            <div className="bg-yellow-50 rounded-2xl p-8 border border-yellow-200 text-center">
              <AlertCircle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
              <p className="text-yellow-800 font-medium">No video or audio available</p>
              <p className="text-yellow-600 text-sm mt-2">Please contact your administrator</p>
            </div>
          )}

          {/* Transcript Toggle */}
          {transcript && (
            <>
              <button
                onClick={() => setShowTranscript(!showTranscript)}
                className="mt-6 w-full py-4 border-2 border-slate-200 rounded-xl text-slate-700 font-semibold hover:bg-slate-50 hover:border-slate-300 transition-all"
              >
                {showTranscript ? 'Hide Transcript' : 'Show Transcript'}
              </button>

              {showTranscript && (
                <div className="mt-4 bg-white rounded-xl p-4 border border-slate-200 text-left text-sm text-slate-700 max-h-32 overflow-y-auto leading-relaxed whitespace-pre-line">
                  {transcript}
                </div>
              )}
            </>
          )}
        </div>

        <p className="text-sm text-slate-400 mb-6">
          In the real test, the {hasVideo ? 'video' : 'audio'} plays once and no transcript is available.
        </p>

        <div className="flex gap-4">
          <button
            onClick={handleBack}
            className="flex-1 py-4 bg-slate-100 text-slate-700 rounded-2xl font-semibold hover:bg-slate-200 transition-all flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <button
            onClick={handleNext}
            className="flex-1 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl font-semibold hover:shadow-xl hover:shadow-blue-500/25 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-3"
          >
            Next
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );

  const renderQuestion = () => {
    if (!currentQuestion) return null;
    const selectedAnswer = answers[currentQuestion.id];

    return (
      <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-slate-200 max-w-6xl mx-auto">
        <div className="mb-6">
          <span className="text-lg text-slate-500 font-medium">
            Question {currentQuestionIndex + 1} of {totalQuestions}
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Question */}
          <div className="bg-gradient-to-br from-slate-50 to-blue-50/50 rounded-2xl p-6 border border-slate-200/80">
            <h3 className="text-xl font-bold text-slate-900 mb-6">
              {currentQuestion.questionText || `Question ${currentQuestionIndex + 1}`}
            </h3>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentQuestion.options.map((option, idx) => (
              <button
                key={option.id}
                onClick={() => handleAnswerSelect(currentQuestion.id, option.id)}
                className={`w-full p-4 rounded-2xl border-2 text-left transition-all flex items-center gap-4 group ${
                  selectedAnswer === option.id
                    ? 'border-blue-500 bg-blue-50 shadow-lg shadow-blue-500/10'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <span className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm transition-all ${
                  selectedAnswer === option.id
                    ? 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white shadow-lg'
                    : 'bg-slate-100 text-slate-600 group-hover:bg-slate-200'
                }`}>
                  {['A', 'B', 'C', 'D'][idx]}
                </span>
                <span className={`flex-1 ${selectedAnswer === option.id ? 'text-slate-900 font-medium' : 'text-slate-700'}`}>
                  {option.text || `Option ${['A', 'B', 'C', 'D'][idx]}`}
                </span>
                {selectedAnswer === option.id && (
                  <CheckCircle className="w-5 h-5 text-blue-600" />
                )}
              </button>
            ))}
          </div>
        </div>

        <div className="flex gap-4 mt-8">
          <button
            onClick={handleBack}
            className="flex-1 py-4 bg-slate-100 text-slate-700 rounded-2xl font-semibold hover:bg-slate-200 transition-all flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <button
            onClick={handleNext}
            disabled={!selectedAnswer}
            className={`flex-1 py-4 rounded-2xl font-semibold transition-all flex items-center justify-center gap-3 ${
              selectedAnswer
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:shadow-xl hover:shadow-blue-500/25 hover:-translate-y-0.5'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            {currentQuestionIndex === allQuestions.length - 1 ? 'Submit' : 'Next'}
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  };

  const renderAnswerKey = () => (
    <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-slate-200 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Answer Key</h2>
        <button
          onClick={() => setPhase('results')}
          className="p-2 hover:bg-slate-100 rounded-lg transition"
        >
          <X className="w-6 h-6 text-slate-500" />
        </button>
      </div>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {allQuestions.map((q, idx) => {
          const isCorrect = answers[q.id] === q.correctAnswer;
          const userAnswer = q.options.find(o => o.id === answers[q.id]);
          const correctAnswer = q.options.find(o => o.id === q.correctAnswer);

          return (
            <div
              key={q.id}
              className={`p-4 rounded-xl border-2 ${
                isCorrect ? 'border-green-200 bg-green-50/50' : 'border-red-200 bg-red-50/50'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  isCorrect ? 'bg-green-500' : 'bg-red-500'
                }`}>
                  {isCorrect ? (
                    <CheckCircle className="w-4 h-4 text-white" />
                  ) : (
                    <X className="w-4 h-4 text-white" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-slate-900 text-sm mb-1">
                    Q{idx + 1}: {q.questionText}
                  </p>
                  <p className="text-sm text-slate-600">
                    Your answer: <span className={`font-medium ${isCorrect ? 'text-green-600' : 'text-red-600'}`}>
                      {userAnswer?.text || 'Not answered'}
                    </span>
                  </p>
                  {!isCorrect && (
                    <p className="text-sm text-green-600 font-medium">
                      Correct: {correctAnswer?.text}
                    </p>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <button
        onClick={() => setPhase('results')}
        className="w-full mt-6 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl font-semibold hover:shadow-xl hover:shadow-blue-500/25 transition-all"
      >
        Back to Results
      </button>
    </div>
  );

  const renderResults = () => {
    const correctCount = allQuestions.filter(q => answers[q.id] === q.correctAnswer).length;
    const percentage = Math.round((correctCount / totalQuestions) * 100);

    return (
      <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-slate-200 max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <div className={`inline-flex items-center justify-center w-24 h-24 rounded-3xl mb-6 shadow-xl ${
            percentage >= 70 ? 'bg-gradient-to-br from-green-400 to-emerald-500 shadow-green-500/25' : 
            percentage >= 50 ? 'bg-gradient-to-br from-amber-400 to-orange-500 shadow-amber-500/25' : 
            'bg-gradient-to-br from-red-400 to-rose-500 shadow-red-500/25'
          }`}>
            {percentage >= 70 ? (
              <CheckCircle className="w-12 h-12 text-white" />
            ) : (
              <AlertCircle className="w-12 h-12 text-white" />
            )}
          </div>
          <h2 className="text-3xl font-bold text-slate-900 mb-2">Test Complete!</h2>
          <p className="text-slate-500 text-lg">Discussion - {scenario.title?.replace(/_/g, ' ')}</p>
        </div>

        <div className="bg-gradient-to-br from-slate-50 to-blue-50/50 rounded-2xl p-8 mb-8 border border-slate-200/80">
          <div className="grid grid-cols-3 gap-8 text-center">
            <div>
              <p className="text-sm text-slate-500 mb-2 font-medium">Score</p>
              <p className="text-5xl font-bold text-slate-900">{correctCount}<span className="text-2xl text-slate-400">/{totalQuestions}</span></p>
            </div>
            <div>
              <p className="text-sm text-slate-500 mb-2 font-medium">Accuracy</p>
              <p className={`text-5xl font-bold ${
                percentage >= 70 ? 'text-green-600' : percentage >= 50 ? 'text-amber-600' : 'text-red-600'
              }`}>{percentage}%</p>
            </div>
            <div>
              <p className="text-sm text-slate-500 mb-2 font-medium">Time Spent</p>
              <p className="text-5xl font-bold text-slate-900">
                {formatTime(testResults?.timeSpent || 0)}
              </p>
            </div>
          </div>
        </div>

        {/* Question Review */}
        <div className="mb-8">
          <h3 className="font-bold text-slate-900 text-lg mb-4">Question Review</h3>
          <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
            {allQuestions.map((q, idx) => {
              const isCorrect = answers[q.id] === q.correctAnswer;
              const userAnswer = q.options.find(o => o.id === answers[q.id]);
              const correctAnswer = q.options.find(o => o.id === q.correctAnswer);

              return (
                <div
                  key={q.id}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    isCorrect ? 'border-green-200 bg-green-50/50' : 'border-red-200 bg-red-50/50'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 shadow-sm ${
                      isCorrect ? 'bg-green-500' : 'bg-red-500'
                    }`}>
                      {isCorrect ? (
                        <CheckCircle className="w-4 h-4 text-white" />
                      ) : (
                        <X className="w-4 h-4 text-white" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-slate-900 text-sm mb-1">
                        Q{idx + 1}: {q.questionText}
                      </p>
                      <p className="text-sm text-slate-600">
                        Your answer: <span className={`font-medium ${isCorrect ? 'text-green-600' : 'text-red-600'}`}>
                          {userAnswer?.text || 'Not answered'}
                        </span>
                      </p>
                      {!isCorrect && (
                        <p className="text-sm text-green-600 font-medium">
                          Correct: {correctAnswer?.text}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex gap-4">
          <button
            onClick={resetTest}
            className="flex-1 py-4 bg-slate-100 text-slate-700 rounded-2xl font-semibold hover:bg-slate-200 transition-all flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-5 h-5" />
            Try Again
          </button>
          <button
            onClick={() => setPhase('answerKey')}
            className="px-6 py-4 rounded-2xl bg-white border-2 border-slate-200 font-semibold hover:bg-slate-50 transition-all"
          >
            Answer Key
          </button>
          <button
            onClick={() => {
              if (testResults) onComplete(testResults);
              else onBack();
            }}
            className="flex-1 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl font-semibold hover:shadow-xl hover:shadow-blue-500/25 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-3"
          >
            Finish
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  };

  // ============== MAIN RENDER ==============

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-xl border-b border-slate-200/80 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <button
                onClick={onBack}
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900 font-medium transition"
              >
                <ArrowLeft className="w-5 h-5" />
                Exit
              </button>
              <span className="font-bold text-slate-900 text-lg">
                Listening • Discussion
              </span>

              {/* Progress Bar */}
              {phase === 'question' && (
                <div className="hidden md:flex items-center gap-3 flex-1 max-w-sm">
                  <div className="flex-1 h-2.5 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 transition-all duration-500 rounded-full"
                      style={{ width: `${progressPercentage}%` }}
                    />
                  </div>
                  <span className="text-sm text-slate-500 font-medium">
                    {Math.round(progressPercentage)}%
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-slate-500 bg-slate-100 px-4 py-2 rounded-full font-medium">
                {phase === 'instructions' ? 'Introduction' :
                 phase === 'media' ? (hasVideo ? 'Video' : 'Listening') :
                 phase === 'question' ? 'Question' : 'Results'}
              </span>

              {/* Timer */}
              {phase === 'question' && (
                <div className={`flex items-center gap-2 px-4 py-2 rounded-full border ${
                  timeLeft < 30 
                    ? 'bg-red-50 border-red-200 text-red-600' 
                    : 'bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 text-blue-600'
                }`}>
                  <Clock className="w-4 h-4" />
                  <span className="font-mono font-bold text-lg">
                    {formatTime(timeLeft)}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-6 py-6">
        {phase === 'instructions' && renderInstructions()}
        {phase === 'media' && renderMedia()}
        {phase === 'question' && renderQuestion()}
        {phase === 'results' && renderResults()}
        {phase === 'answerKey' && renderAnswerKey()}
      </main>
    </div>
  );
};

export default ListeningDiscussionTest;
