// src/pages/Listening/5. Discussion/ListeningDiscussionTest.tsx
import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, Play, Pause, Volume2, VolumeX, 
  ChevronRight, CheckCircle, Clock, AlertCircle,
  FileText, RotateCcw
} from 'lucide-react';

interface Question {
  id: string;
  questionText: string;
  type: string;
  options: { id: string; text: string }[];
  correctAnswer: string;
  audioUrl?: string;
  transcript?: string;
}

interface Section {
  id: string;
  title: string;
  audioUrl?: string;
  audioDuration: number;
  transcript?: string;
  questions: Question[];
}

interface ScenarioData {
  id: string;
  title: string;
  skill: string;
  taskName: string;
  taskType: string;
  totalTime: number;
  instructions?: string;
  contextImage?: string;
  videoUrl?: string;
  sections: Section[];
  uploadedFiles?: any;
}

interface Props {
  scenario: ScenarioData;
  onBack: () => void;
  onComplete: (results: any) => void;
}

export default function ListeningDiscussionTest({ scenario, onBack, onComplete }: Props) {
  const [phase, setPhase] = useState<'media' | 'questions' | 'results'>('media');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [showTranscript, setShowTranscript] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [mediaEnded, setMediaEnded] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(90); // 1:30 for questions
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  // Get video URL from scenario
  const videoUrl = scenario.videoUrl || scenario.uploadedFiles?.videoFile?.storageUrl || scenario.uploadedFiles?.videoFile?.data;
  
  // Get audio URL as fallback
  const audioUrl = scenario.sections?.[0]?.audioUrl || scenario.uploadedFiles?.sectionAudios?.[0]?.data;
  
  // Get transcript
  const transcript = scenario.sections?.[0]?.transcript || '';
  
  // Get all questions from all sections
  const allQuestions = scenario.sections?.flatMap(s => s.questions) || [];
  
  // Determine if we should show video or audio
  const hasVideo = !!videoUrl;
  const hasAudio = !!audioUrl;
  
  // Timer for questions phase
  useEffect(() => {
    if (phase === 'questions' && timeRemaining > 0) {
      const timer = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            handleSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [phase, timeRemaining]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const togglePlay = () => {
    const media = hasVideo ? videoRef.current : audioRef.current;
    if (media) {
      if (isPlaying) {
        media.pause();
      } else {
        media.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    const media = hasVideo ? videoRef.current : audioRef.current;
    if (media) {
      setCurrentTime(media.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    const media = hasVideo ? videoRef.current : audioRef.current;
    if (media) {
      setDuration(media.duration);
    }
  };

  const handleMediaEnded = () => {
    setIsPlaying(false);
    setMediaEnded(true);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const media = hasVideo ? videoRef.current : audioRef.current;
    const newTime = (parseFloat(e.target.value) / 100) * duration;
    if (media) {
      media.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const toggleMute = () => {
    const media = hasVideo ? videoRef.current : audioRef.current;
    if (media) {
      media.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleAnswerSelect = (questionIndex: number, answerId: string) => {
    setAnswers(prev => ({ ...prev, [questionIndex]: answerId }));
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < allQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      handleSubmit();
    }
  };

  const handleSubmit = () => {
    const results = {
      totalQuestions: allQuestions.length,
      answered: Object.keys(answers).length,
      correct: allQuestions.filter((q, idx) => answers[idx] === q.correctAnswer).length,
      answers: answers
    };
    setPhase('results');
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  // MEDIA PHASE - Show video or audio
  if (phase === 'media') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <div className="max-w-4xl mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <button
                onClick={onBack}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Exit</span>
              </button>
              <div className="text-center">
                <h1 className="font-semibold">Listening • Discussion</h1>
                <p className="text-sm text-gray-500">{scenario.title}</p>
              </div>
              <div className="flex items-center gap-2 text-blue-600">
                <Clock className="w-5 h-5" />
                <span className="font-mono font-semibold">
                  {formatTime(Math.floor(duration - currentTime))}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto px-6 py-8">
          {/* Instructions */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <p className="text-blue-800">
                {scenario.instructions || 'Watch the discussion between the speakers. You will hear it only'} 
                <span className="text-orange-600 font-semibold"> once</span>.
              </p>
            </div>
          </div>

          {/* Video or Audio Player */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6">
            {hasVideo ? (
              /* VIDEO PLAYER */
              <div className="relative">
                <video
                  ref={videoRef}
                  src={videoUrl}
                  className="w-full aspect-video bg-black"
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  onEnded={handleMediaEnded}
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                />
                
                {/* Video Controls Overlay */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                  <div className="flex items-center gap-4">
                    <button
                      onClick={togglePlay}
                      className="w-12 h-12 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition"
                    >
                      {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
                    </button>
                    
                    <div className="flex-1">
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={progress}
                        onChange={handleSeek}
                        className="w-full h-1 bg-white/30 rounded-full appearance-none cursor-pointer"
                      />
                    </div>
                    
                    <span className="text-white text-sm font-mono">
                      {formatTime(currentTime)} / {formatTime(duration)}
                    </span>
                    
                    <button
                      onClick={toggleMute}
                      className="text-white hover:text-white/80"
                    >
                      {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
              </div>
            ) : hasAudio ? (
              /* AUDIO PLAYER */
              <div className="p-6">
                <audio
                  ref={audioRef}
                  src={audioUrl}
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  onEnded={handleMediaEnded}
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                />
                
                <div className="text-center mb-6">
                  <h3 className="text-lg font-semibold text-gray-800">Audio</h3>
                  <p className="text-sm text-gray-500">{allQuestions.length} questions follow</p>
                </div>
                
                <div className="flex items-center gap-4">
                  <button
                    onClick={togglePlay}
                    className="w-14 h-14 bg-blue-600 hover:bg-blue-700 rounded-full flex items-center justify-center text-white transition shadow-lg"
                  >
                    {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
                  </button>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-mono text-gray-600 w-12">
                        {formatTime(currentTime)}
                      </span>
                      <div className="flex-1 relative h-2 bg-gray-200 rounded-full">
                        <div 
                          className="absolute h-full bg-blue-600 rounded-full"
                          style={{ width: `${progress}%` }}
                        />
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={progress}
                          onChange={handleSeek}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                      </div>
                      <span className="text-sm font-mono text-gray-600 w-12">
                        {formatTime(duration)}
                      </span>
                    </div>
                  </div>
                  
                  <button
                    onClick={toggleMute}
                    className="p-2 text-gray-600 hover:text-gray-800"
                  >
                    {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                  </button>
                </div>
                
                {/* Tip */}
                <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-center">
                  <p className="text-yellow-800 text-sm">
                    <span className="font-semibold">Tip:</span> focus on keywords (numbers, dates, reasons, next steps).
                  </p>
                </div>
              </div>
            ) : (
              /* NO MEDIA */
              <div className="p-8 text-center">
                <AlertCircle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
                <p className="text-gray-600">No video or audio available for this test.</p>
              </div>
            )}
          </div>

          {/* Transcript Toggle */}
          {transcript && (
            <div className="mb-6">
              <button
                onClick={() => setShowTranscript(!showTranscript)}
                className="w-full py-3 border-2 border-gray-200 rounded-xl hover:bg-gray-50 flex items-center justify-center gap-2 text-gray-700"
              >
                <FileText className="w-5 h-5" />
                {showTranscript ? 'Hide Transcript' : 'Show Transcript'}
              </button>
              
              {showTranscript && (
                <div className="mt-4 p-4 bg-gray-50 rounded-xl border max-h-60 overflow-y-auto">
                  <pre className="whitespace-pre-wrap text-sm text-gray-700 font-sans">
                    {transcript}
                  </pre>
                </div>
              )}
            </div>
          )}

          {/* Info text */}
          <p className="text-center text-gray-500 text-sm mb-6">
            In the real test, the {hasVideo ? 'video' : 'audio'} plays once and no transcript is available.
          </p>

          {/* Navigation Buttons */}
          <div className="flex gap-4">
            <button
              onClick={onBack}
              className="flex-1 py-4 border-2 border-gray-200 rounded-xl hover:bg-gray-50 flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-5 h-5" />
              Back
            </button>
            <button
              onClick={() => setPhase('questions')}
              disabled={!mediaEnded && (hasVideo || hasAudio)}
              className={`flex-1 py-4 rounded-xl flex items-center justify-center gap-2 font-semibold transition
                ${mediaEnded || (!hasVideo && !hasAudio)
                  ? 'bg-blue-600 hover:bg-blue-700 text-white'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
            >
              Next
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
          
          {!mediaEnded && (hasVideo || hasAudio) && (
            <p className="text-center text-gray-400 text-sm mt-3">
              Please {hasVideo ? 'watch' : 'listen to'} the entire {hasVideo ? 'video' : 'audio'} before proceeding
            </p>
          )}
        </div>
      </div>
    );
  }

  // QUESTIONS PHASE
  if (phase === 'questions') {
    const currentQuestion = allQuestions[currentQuestionIndex];
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <div className="max-w-4xl mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <button
                onClick={onBack}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Exit</span>
              </button>
              <div className="text-center">
                <h1 className="font-semibold">Question {currentQuestionIndex + 1} of {allQuestions.length}</h1>
              </div>
              <div className={`flex items-center gap-2 ${timeRemaining < 30 ? 'text-red-600' : 'text-blue-600'}`}>
                <Clock className="w-5 h-5" />
                <span className="font-mono font-semibold">{formatTime(timeRemaining)}</span>
              </div>
            </div>
            
            {/* Progress bar */}
            <div className="mt-3 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-600 transition-all duration-300"
                style={{ width: `${((currentQuestionIndex + 1) / allQuestions.length) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Question Content */}
        <div className="max-w-2xl mx-auto px-6 py-8">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-6">
              {currentQuestion?.questionText || `Question ${currentQuestionIndex + 1}`}
            </h2>
            
            <div className="space-y-3">
              {currentQuestion?.options.map((option, idx) => (
                <button
                  key={option.id}
                  onClick={() => handleAnswerSelect(currentQuestionIndex, option.id)}
                  className={`w-full p-4 rounded-xl border-2 text-left transition flex items-center gap-4
                    ${answers[currentQuestionIndex] === option.id
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                >
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm
                    ${answers[currentQuestionIndex] === option.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-600'
                    }`}>
                    {['A', 'B', 'C', 'D'][idx]}
                  </span>
                  <span className="flex-1">{option.text}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex gap-4 mt-8">
            <button
              onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
              disabled={currentQuestionIndex === 0}
              className={`flex-1 py-4 border-2 border-gray-200 rounded-xl flex items-center justify-center gap-2
                ${currentQuestionIndex === 0 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-50'}`}
            >
              <ArrowLeft className="w-5 h-5" />
              Previous
            </button>
            <button
              onClick={handleNextQuestion}
              className="flex-1 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl flex items-center justify-center gap-2 font-semibold"
            >
              {currentQuestionIndex === allQuestions.length - 1 ? 'Submit' : 'Next'}
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // RESULTS PHASE
  if (phase === 'results') {
    const correctCount = allQuestions.filter((q, idx) => answers[idx] === q.correctAnswer).length;
    const percentage = Math.round((correctCount / allQuestions.length) * 100);
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-lg p-8 max-w-md w-full text-center">
          <div className={`w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center
            ${percentage >= 70 ? 'bg-green-100' : percentage >= 50 ? 'bg-yellow-100' : 'bg-red-100'}`}>
            <CheckCircle className={`w-10 h-10 
              ${percentage >= 70 ? 'text-green-600' : percentage >= 50 ? 'text-yellow-600' : 'text-red-600'}`} 
            />
          </div>
          
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Test Complete!</h2>
          <p className="text-gray-600 mb-6">{scenario.title}</p>
          
          <div className="bg-gray-50 rounded-xl p-6 mb-6">
            <div className="text-4xl font-bold text-blue-600 mb-2">{correctCount}/{allQuestions.length}</div>
            <p className="text-gray-600">Correct Answers</p>
            <div className="mt-4 h-3 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className={`h-full rounded-full ${percentage >= 70 ? 'bg-green-500' : percentage >= 50 ? 'bg-yellow-500' : 'bg-red-500'}`}
                style={{ width: `${percentage}%` }}
              />
            </div>
            <p className="text-sm text-gray-500 mt-2">{percentage}% Score</p>
          </div>
          
          <div className="flex gap-4">
            <button
              onClick={onBack}
              className="flex-1 py-3 border-2 border-gray-200 rounded-xl hover:bg-gray-50 flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-5 h-5" />
              Back
            </button>
            <button
              onClick={() => {
                setPhase('media');
                setCurrentQuestionIndex(0);
                setAnswers({});
                setMediaEnded(false);
                setCurrentTime(0);
                setTimeRemaining(90);
              }}
              className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl flex items-center justify-center gap-2 font-semibold"
            >
              <RotateCcw className="w-5 h-5" />
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
