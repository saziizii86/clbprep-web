import { Resend } from "resend";

export default async ({ req, res, log, error }) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return res.send("", 204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    });
  }

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
    const { name, email, feedbackType, message, attachments } = body;

    if (!message) {
      return res.json({ ok: false, error: "Message is required" }, 400, {
        "Access-Control-Allow-Origin": "*",
      });
    }

    const resend = new Resend(process.env.RESEND_API_KEY);

    await resend.emails.send({
      from: process.env.FROM_EMAIL,
      to: process.env.TO_EMAIL,
      reply_to: email || process.env.TO_EMAIL,
      subject: `[CLBPrep] ${feedbackType || "Feedback"} from ${name || "Anonymous"}`,
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
          <div style="background:linear-gradient(135deg,#4f46e5,#6366f1);padding:24px;border-radius:12px 12px 0 0">
            <h2 style="color:white;margin:0;font-size:20px">📬 New Feedback — CLBPrep</h2>
          </div>
          <table style="border-collapse:collapse;width:100%;font-size:14px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px;overflow:hidden">
            <tr>
              <td style="padding:12px 16px;font-weight:600;background:#f8fafc;width:130px;color:#475569">Name</td>
              <td style="padding:12px 16px;color:#1e293b">${name || "Anonymous"}</td>
            </tr>
            <tr>
              <td style="padding:12px 16px;font-weight:600;background:#f8fafc;color:#475569">Email</td>
              <td style="padding:12px 16px;color:#1e293b">${email || "Not provided"}</td>
            </tr>
            <tr>
              <td style="padding:12px 16px;font-weight:600;background:#f8fafc;color:#475569">Type</td>
              <td style="padding:12px 16px;color:#1e293b">${feedbackType || "General"}</td>
            </tr>
            <tr>
              <td style="padding:12px 16px;font-weight:600;background:#f8fafc;color:#475569;vertical-align:top">Message</td>
              <td style="padding:12px 16px;color:#1e293b;line-height:1.6">${message.replace(/\n/g, "<br/>")}</td>
            </tr>
            <tr>
              <td style="padding:12px 16px;font-weight:600;background:#f8fafc;color:#475569">Attachments</td>
              <td style="padding:12px 16px;color:#1e293b">${attachments || "None"}</td>
            </tr>
          </table>
          <p style="font-size:12px;color:#94a3b8;margin-top:16px;text-align:center">Sent via CLBPrep Feedback Form</p>
        </div>
      `,
    });

    log("Feedback email sent successfully");
    return res.json({ ok: true }, 200, { "Access-Control-Allow-Origin": "*" });

  } catch (err) {
    error("Failed to send email: " + err.message);
    return res.json({ ok: false, error: err.message }, 500, {
      "Access-Control-Allow-Origin": "*",
    });
  }
};
