import { Resend } from "resend";
import { Client, Users } from "node-appwrite";

export default async ({ req, res, log, error }) => {
  if (req.method === "OPTIONS") {
    return res.send("", 204, { "Access-Control-Allow-Origin": "*" });
  }

  // ── Parse body ──
  let body = {};
  try {
    body = typeof req.body === "string" ? JSON.parse(req.body) : (req.body || {});
  } catch(e) {
    error("Body parse failed: " + e.message);
    return res.json({ ok: false, error: "Invalid JSON body" }, 400);
  }

  const { userId, email, name } = body;
  log("=== START === userId=" + userId + " email=" + email);

  if (!userId || !email) {
    error("Missing userId or email");
    return res.json({ ok: false, error: "userId and email are required" }, 400);
  }

  // ── Env vars ──
  const endpoint  = (process.env.APPWRITE_ENDPOINT || "").replace(/\/$/, "");
  const projectId = process.env.APPWRITE_PROJECT_ID || "";
  const apiKey    = process.env.APPWRITE_API_KEY || "";
  const appUrl    = (process.env.APP_URL || "http://127.0.0.1:3000").replace(/\/$/, "");
  const resendKey = process.env.RESEND_API_KEY || "";

  log("endpoint=" + endpoint);
  log("projectId=" + projectId);
  log("apiKey starts with=" + apiKey.substring(0, 12));
  log("appUrl=" + appUrl);
  log("resendKey starts with=" + resendKey.substring(0, 8));

  if (!endpoint) { error("Missing APPWRITE_ENDPOINT"); return res.json({ ok: false, error: "Missing APPWRITE_ENDPOINT" }, 500); }
  if (!projectId) { error("Missing APPWRITE_PROJECT_ID"); return res.json({ ok: false, error: "Missing APPWRITE_PROJECT_ID" }, 500); }
  if (!apiKey) { error("Missing APPWRITE_API_KEY"); return res.json({ ok: false, error: "Missing APPWRITE_API_KEY" }, 500); }
  if (!resendKey) { error("Missing RESEND_API_KEY"); return res.json({ ok: false, error: "Missing RESEND_API_KEY" }, 500); }

  // ── Step 1: Create token ──
  let secret = "";
  try {
    const client = new Client().setEndpoint(endpoint).setProject(projectId).setKey(apiKey);
    const users = new Users(client);

    log("Calling users.createToken(userId=" + userId + ")...");
    const token = await users.createToken(userId);
    log("Token raw response: " + JSON.stringify(token));

    secret = token?.secret || "";
    if (!secret) {
      throw new Error("Token has no .secret field. Full response: " + JSON.stringify(token));
    }
    log("Secret obtained (first 10 chars): " + secret.substring(0, 10));
  } catch(e) {
    error("createToken FAILED: " + e.message);
    return res.json({ ok: false, error: "Token creation failed: " + e.message }, 500);
  }

  // ── Step 2: Build link ──
  const verificationLink = `${appUrl}/verify?userId=${encodeURIComponent(userId)}&secret=${encodeURIComponent(secret)}`;
  log("Verification link: " + verificationLink);

  // ── Step 3: Send email ──
  try {
    const resend = new Resend(resendKey);
    const sendResult = await resend.emails.send({
      from: "CLBPrep <noreply@clbprep.com>",
      to: email,
      subject: "Verify your CLBPrep account",
      html: `
        <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:24px">
          <div style="background:linear-gradient(135deg,#7c3aed,#6d28d9);padding:32px 24px;border-radius:16px 16px 0 0;text-align:center">
            <h1 style="color:white;margin:0;font-size:22px;font-weight:700">CLBPrep</h1>
            <p style="color:rgba(255,255,255,0.8);margin:6px 0 0;font-size:14px">CELPIP Preparation Platform</p>
          </div>
          <div style="background:#fff;border:1px solid #e2e8f0;border-top:none;padding:32px 24px;border-radius:0 0 16px 16px">
            <h2 style="margin:0 0 8px;font-size:20px;color:#1e293b">${name ? "Hi " + name + "," : "Hi,"} Verify your email</h2>
            <p style="color:#64748b;font-size:14px;line-height:1.6;margin:0 0 24px">
              Thanks for signing up! Click below to activate your CLBPrep account. This link expires in <strong>1 hour</strong>.
            </p>
            <div style="text-align:center;margin:28px 0">
              <a href="${verificationLink}" style="display:inline-block;background:linear-gradient(135deg,#7c3aed,#6d28d9);color:white;text-decoration:none;padding:14px 36px;border-radius:12px;font-size:15px;font-weight:600">
                Activate My Account
              </a>
            </div>
            <p style="color:#94a3b8;font-size:12px;text-align:center;margin:0 0 8px">Or copy this link:</p>
            <p style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:11px;color:#64748b;word-break:break-all;margin:0 0 24px">${verificationLink}</p>
            <hr style="border:none;border-top:1px solid #f1f5f9;margin:24px 0"/>
            <p style="color:#94a3b8;font-size:12px;margin:0">
              If you didn&apos;t sign up for CLBPrep, ignore this email.<br/>
              Help: <a href="mailto:support@clbprep.com" style="color:#7c3aed">support@clbprep.com</a>
            </p>
          </div>
          <p style="text-align:center;color:#cbd5e1;font-size:11px;margin-top:16px">&copy; ${new Date().getFullYear()} CLBPrep</p>
        </div>
      `,
    });

    log("Resend response: " + JSON.stringify(sendResult));

    if (sendResult.error) {
      throw new Error("Resend error: " + JSON.stringify(sendResult.error));
    }

    log("=== SUCCESS === Email sent to " + email);
    return res.json({ ok: true }, 200);

  } catch(e) {
    error("Resend FAILED: " + e.message);
    return res.json({ ok: false, error: "Email send failed: " + e.message }, 500);
  }
};
