import { Resend } from "resend";
import { Client, Account } from "node-appwrite";

export default async ({ req, res, log, error }) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return res.send("", 204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    });
  }

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
    const { userId, email, name } = body;

    if (!userId || !email) {
      return res.json({ ok: false, error: "userId and email are required" }, 400, {
        "Access-Control-Allow-Origin": "*",
      });
    }

    // ── Step 1: Generate verification token using Appwrite server SDK ──
    // We use the user's JWT (passed from client) to call createVerification on their behalf
    const client = new Client()
      .setEndpoint(process.env.APPWRITE_ENDPOINT || "https://cloud.appwrite.io/v1")
      .setProject(process.env.APPWRITE_PROJECT_ID)
      .setJWT(body.jwt); // user's JWT passed from frontend

    const accountApi = new Account(client);

    // Generate the verification token — redirect to /verify page
    const verifyUrl = `${process.env.APP_URL}/verify`;
    const token = await accountApi.createVerification(verifyUrl);

    log("Verification token created for: " + email);

    // ── Step 2: Send the email via Resend ──
    const resend = new Resend(process.env.RESEND_API_KEY);

    // Build the verification link (same format Appwrite uses)
    const verificationLink = `${process.env.APP_URL}/verify?userId=${token.userId}&secret=${token.secret}`;

    await resend.emails.send({
      from: `CLBPrep <noreply@clbprep.com>`,
      to: email,
      subject: "Verify your CLBPrep account",
      html: `
        <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:24px">

          <!-- Header -->
          <div style="background:linear-gradient(135deg,#7c3aed,#6d28d9);padding:32px 24px;border-radius:16px 16px 0 0;text-align:center">
            <div style="display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;background:rgba(255,255,255,0.2);border-radius:12px;margin-bottom:12px">
              <span style="font-size:24px">C</span>
            </div>
            <h1 style="color:white;margin:0;font-size:22px;font-weight:700">CLBPrep</h1>
            <p style="color:rgba(255,255,255,0.8);margin:6px 0 0;font-size:14px">CELPIP Preparation Platform</p>
          </div>

          <!-- Body -->
          <div style="background:#ffffff;border:1px solid #e2e8f0;border-top:none;padding:32px 24px;border-radius:0 0 16px 16px">
            <h2 style="margin:0 0 8px;font-size:20px;color:#1e293b">
              ${name ? `Hi ${name}, verify` : "Verify"} your email ✉️
            </h2>
            <p style="color:#64748b;font-size:14px;line-height:1.6;margin:0 0 24px">
              Thanks for signing up! Click the button below to activate your account.
              This link expires in <strong>1 hour</strong>.
            </p>

            <!-- CTA Button -->
            <div style="text-align:center;margin:28px 0">
              <a href="${verificationLink}"
                style="display:inline-block;background:linear-gradient(135deg,#7c3aed,#6d28d9);color:white;text-decoration:none;padding:14px 36px;border-radius:12px;font-size:15px;font-weight:600;letter-spacing:0.01em">
                Activate My Account
              </a>
            </div>

            <p style="color:#94a3b8;font-size:12px;text-align:center;margin:0 0 16px">
              Or copy this link into your browser:
            </p>
            <p style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 12px;font-size:11px;color:#64748b;word-break:break-all;margin:0 0 24px">
              ${verificationLink}
            </p>

            <hr style="border:none;border-top:1px solid #f1f5f9;margin:24px 0" />

            <p style="color:#94a3b8;font-size:12px;line-height:1.6;margin:0">
              If you didn't create a CLBPrep account, you can safely ignore this email.<br/>
              Need help? <a href="mailto:support@clbprep.com" style="color:#7c3aed">support@clbprep.com</a>
            </p>
          </div>

          <p style="text-align:center;color:#cbd5e1;font-size:11px;margin-top:16px">
            © ${new Date().getFullYear()} CLBPrep — Halifax, Nova Scotia, Canada
          </p>
        </div>
      `,
    });

    log("Verification email sent to: " + email);
    return res.json({ ok: true }, 200, { "Access-Control-Allow-Origin": "*" });

  } catch (err) {
    error("Failed: " + err.message);
    return res.json({ ok: false, error: err.message }, 500, {
      "Access-Control-Allow-Origin": "*",
    });
  }
};
